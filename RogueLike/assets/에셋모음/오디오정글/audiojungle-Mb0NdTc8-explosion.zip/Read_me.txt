Hello dear buyer! 

Thanks for purchasing my product!!! 
Hope you will enjoy it. 
Kindly ask you to take a few seconds to rate this tune if you like it! 
If any questions arise please feel free to contact me. 

mchugunov@gmail.com

Best Regards!
Mikhail Chugunov
Audio Mechanica Music
